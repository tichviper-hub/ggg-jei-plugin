GGG JEI Plugin 外部配置

把本文件夹放到 Minecraft 实例的 config/ggg_jei_plugin/。

templates.json：JEI 页面模板，只描述页面布局。
template_recipes.json：填入模板的数据，每条数据通过 templateId 指向模板 id。

如果只安装 JAR 而不提供配置，游戏第一次启动时也会自动创建这两个 JSON，并写入只引用原版物品的熔炉样例。
修改模板或配方 JSON 后，通常需要重启 Minecraft 才能稳定刷新 JEI 分类。
