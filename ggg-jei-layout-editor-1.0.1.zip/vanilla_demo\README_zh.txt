这是一个只使用原版 Minecraft 物品的 GGG JEI Plugin 样例。

templates.json：
  可直接用 tools/jei_layout_editor.html 的“读取草稿”按钮打开，用来查看和编辑页面布局。

template_recipes.json：
  可复制到 config/ggg_jei_plugin/template_recipes.json，用来让游戏内 JEI 生成两条样例页面。

如果想在游戏内测试：
  1. 把 templates.json 复制到 Minecraft 实例的 config/ggg_jei_plugin/templates.json。
  2. 把 template_recipes.json 复制到 Minecraft 实例的 config/ggg_jei_plugin/template_recipes.json。
  3. 重启 Minecraft。

这个样例不会注册真实配方，只是给 JEI 插件展示页面用。
