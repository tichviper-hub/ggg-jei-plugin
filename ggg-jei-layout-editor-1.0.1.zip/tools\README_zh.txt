GGG JEI 页面布局编辑器

用途：
  用浏览器编辑 ggg-jei-plugin 使用的 templates.json 页面布局。

使用方法：
  1. 双击 open_jei_layout_editor.bat。
  2. 在浏览器中编辑页面。
  3. 导出 templates.json。
  4. 把导出的 JSON 放进 Minecraft 实例的 config/ggg_jei_plugin/templates.json。

注意：
  这个工具不是 Minecraft Mod，不要放进 mods 文件夹。
  CurseForge 分发时建议作为 Additional File / Optional File 单独上传。
  普通玩家只需要安装 ggg-jei-plugin 的 JAR；只有需要编辑页面模板的人才需要这个工具。
