@echo off
setlocal
set "HERE=%~dp0"
start "" "%HERE%jei_layout_editor.html"
